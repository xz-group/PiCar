import serial
import numpy as np
ser = serial.Serial('/COM4',9600)
