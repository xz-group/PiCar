File descriptions:
motorcontrol.cmp (Copper, component side)
motorcontrol.drd (Drill file)
motorcontrol.dri (Drill Station Info File) � Usually not needed
motorcontrol.gpi (Photoplotter Info File) � Usually not needed
motorcontrol.plc (Silk screen, component side)
motorcontrol.pls (Silk screen, solder side)
motorcontrol.sol (Copper, solder side)
motorcontrol.stc (Solder stop mask, component side)
motorcontrol.sts (Solder stop mask, solder side)
motorcontrol.crc (Cream frame, component side)
motorcontrol.crs (Cream frame, solder side)
motorcontrol.ly2 (Inner layer 2, Eagle Route2)
motorcontrol.l15 (Inner layer 3, Eagle Route15)